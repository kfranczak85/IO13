package org.example.kalkulator;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;

public class HelloController {

    @FXML
    private Button battonMinus;

    @FXML
    private Button buttonPlus;

    @FXML
    private Label labelNUmber1;

    @FXML
    private Label labelNUmber2;

    @FXML
    private Label labelResult;

    @FXML
    private Label labelTitle;

    @FXML
    private AnchorPane mainPanel;

    @FXML
    private TextField textNumber1;

    @FXML
    private TextField textNumber2;


    @FXML
    public ListView<String> listOfOperations;

    @FXML
    void onMinus(ActionEvent event) {
        try {
            double liczba1 = Double.parseDouble(textNumber1.getText());
            double liczba2 = Double.parseDouble(textNumber2.getText());
            double wynik = liczba1 - liczba2;
            labelResult.setText("Wynik :" + Double.toString(wynik));
            listOfOperations.getItems().add(textNumber1.getText() + "-" + textNumber2.getText() + "=" + wynik);
        } catch (NumberFormatException e) {
            labelResult.setText("Błąd Konwersji");
        }

    }

    @FXML
    void onPlus(ActionEvent event) {
        try {
            double liczba1 = Double.parseDouble(textNumber1.getText());
            double liczba2 = Double.parseDouble(textNumber2.getText());
            double wynik = liczba1 + liczba2;

            labelResult.setText("Wynik :" + Double.toString(wynik));
            listOfOperations.getItems().add(textNumber1.getText() + "+" + textNumber2.getText() + "=" + wynik);

        } catch (NumberFormatException e) {
            labelResult.setText("Błąd Konwersji");
        }
    }

    @FXML
    private Button buttonClear;
    @FXML
    private Button buttonSave;

    @FXML
    void onClear(ActionEvent event) {
        listOfOperations.getItems().clear();
    }

    @FXML
    void onSave(ActionEvent event) {
        try {
            FileChooser chooser = new FileChooser();
            File file = chooser.showSaveDialog(new Stage());
            chooser.getExtensionFilters().addAll(
                    new FileChooser.ExtensionFilter("Text Files", "*.txt"));
//                    new ExtensionFilter("Image Files", "*.png", "*.jpg", "*.gif"),
//                    new ExtensionFilter("Audio Files", "*.wav", "*.mp3", "*.aac"),
//                    new ExtensionFilter("All Files", "*.*"));

            if (file != null) {
                PrintWriter out = new PrintWriter(file.getAbsolutePath() + ".txt");
                out.println("Zapisane operacje");
                for (String dane : listOfOperations.getItems()) {
                    out.println(dane);
                }
                out.close();
            }
        } catch (IOException e) {
            System.out.println("Błąd zapisu");
        }
    }

    @FXML
    private Button buttonDivide;

    @FXML
    private Button buttonMultiplication;

    @FXML
    void onDivide(ActionEvent event) {
        try {
            double liczba1 = Double.parseDouble(textNumber1.getText());
            double liczba2 = Double.parseDouble(textNumber2.getText());
            double wynik;

            try{
                if (liczba2==0){
                    int wynik1 = (int)liczba1/(int) liczba2;
                }else {
                    wynik = liczba1 / liczba2;
                    labelResult.setText("Wynik :" + Double.toString(wynik));
                    listOfOperations.getItems().add(textNumber1.getText() + "/" + textNumber2.getText() + "=" + wynik);
                }
            }catch (ArithmeticException e){
                labelResult.setText("Nie dziel przez zero!");
            }

        } catch (NumberFormatException e) {
            labelResult.setText("Błąd Konwersji");
        }
    }

    @FXML
    void onMultiplication(ActionEvent event) {
        try {
            double liczba1 = Double.parseDouble(textNumber1.getText());
            double liczba2 = Double.parseDouble(textNumber2.getText());
            double wynik = liczba1 * liczba2;

            labelResult.setText("Wynik :" + Double.toString(wynik));
            listOfOperations.getItems().add(textNumber1.getText() + "x" + textNumber2.getText() + "=" + wynik);

        } catch (NumberFormatException e) {
            labelResult.setText("Błąd Konwersji");
        }
    }


    @FXML
    private Button buttonPower;

    @FXML
    private Button buttonSqrt;

    @FXML
    void onSqrt(ActionEvent event) {
        try {
            double liczba1 = Double.parseDouble(textNumber1.getText());
            double liczba2 = Double.parseDouble(textNumber2.getText());
            double wynik;
            try{
                if (liczba2==0){
                    int wynik1 = (int)liczba1/(int) liczba2;
                }else {
                    wynik = Math.pow(liczba1, 1 / liczba2);
                    labelResult.setText("Wynik :" + Double.toString(wynik));
                    listOfOperations.getItems().add("Pierwiastek stopnia " + textNumber2.getText() + " z liczby: " + textNumber1.getText() + "=" + wynik);
                }
            }catch (ArithmeticException e){
                labelResult.setText("Błędny stopień pierwiastka");
            }

        } catch (NumberFormatException e) {
            labelResult.setText("Błąd Konwersji");
        }

    }

    @FXML
    void onPower(ActionEvent event) {
        try {
            double liczba1 = Double.parseDouble(textNumber1.getText());
            double liczba2 = Double.parseDouble(textNumber2.getText());
            double wynik = Math.pow(liczba1, liczba2);

            labelResult.setText("Wynik :" + Double.toString(wynik));
            listOfOperations.getItems().add(textNumber1.getText() + " do potęgi " + textNumber2.getText() + "=" + wynik);

        } catch (NumberFormatException e) {
            labelResult.setText("Błąd Konwersji");
        }
    }

}







